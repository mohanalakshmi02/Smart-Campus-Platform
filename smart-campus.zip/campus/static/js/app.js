document.getElementById('burger')?.addEventListener('click',()=>document.getElementById('side').classList.toggle('open'));
document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm))e.preventDefault()}));
const fac=document.getElementById('b_fac'),day=document.getElementById('b_start'),box=document.getElementById('slots');
async function check(){
  if(!fac||!fac.value||!day.value)return;
  try{const r=await fetch(`/api/availability?facility_id=${fac.value}&date=${day.value.slice(0,10)}`);const d=await r.json();
    if(!r.ok)throw new Error(d.error);
    box.innerHTML=d.booked.length?'<b>Already booked that day:</b> '+d.booked.map(b=>`<span class="slot">${b.start_time.slice(11)}–${b.end_time.slice(11)} (${b.status})</span>`).join(''):'<span class="badge approved">Fully available on this date</span>';
  }catch(e){box.textContent='Could not check availability.'}
}
fac?.addEventListener('change',check);day?.addEventListener('change',check);check();
